"""
Design: O3 CPU Core and Processor Definition
Author: Kuan-Hsi(Vic) Chen
Email : s179038@gmail.com
"""

from gem5.isas import ISA

from gem5.components.processors.base_cpu_core import BaseCPUCore
from gem5.components.processors.base_cpu_processor import BaseCPUProcessor

from m5.objects import X86O3CPU
from m5.objects import TournamentBP

class MyOutOfOrderCore(BaseCPUCore):
    def __init__(self, width, rob_size, num_int_regs, num_fp_regs, sq_lq_entries=128):
        super().__init__(X86O3CPU(), ISA.X86)
        self.core.fetchWidth  = width
        self.core.decodeWidth = width
        self.core.renameWidth = width
        self.core.issueWidth  = width
        self.core.wbWidth     = width
        self.core.commitWidth = width

        self.core.numROBEntries = rob_size

        self.core.LQEntries = sq_lq_entries
        self.core.SQEntries = sq_lq_entries

        self.core.numPhysIntRegs   = num_int_regs
        self.core.numPhysFloatRegs = num_fp_regs

        self.core.branchPred = TournamentBP()

class MyO3CPU(BaseCPUProcessor):
    def __init__(self, width, rob_size, num_int_regs, num_fp_regs):
        """
        :param width: sets the width of fetch, decode, raname, issue, wb, and
        commit stages.
        :param rob_size: determine the number of entries in the reorder buffer.
        :param num_int_regs: determines the size of the integer register file.
        :param num_int_regs: determines the size of the vector/floating point
        register file.
        :param sq_lq_entries: number of entries in the store/load queues.
        """
        cores = [MyOutOfOrderCore(width, rob_size, num_int_regs, num_fp_regs)]
        super().__init__(cores)
