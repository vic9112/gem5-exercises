from gem5.coherence_protocol import CoherenceProtocol
from gem5.components.boards.x86_board import X86Board
from gem5.components.memory.single_channel import SingleChannelDDR4_2400
from gem5.components.memory.multi_channel import DualChannelDDR4_2400
from gem5.components.processors.cpu_types import CPUTypes
from gem5.isas import ISA
from gem5.resources.resource import KernelResource, DiskImageResource
from gem5.simulate.exit_event import ExitEvent
from gem5.simulate.simulator import Simulator
from gem5.utils.requires import requires
from gem5.components.processors.simple_switchable_processor import ( SimpleSwitchableProcessor, )

requires(
    isa_required=ISA.X86,
    kvm_required=True,
)

import argparse
from component.hierarchy import PrivateL1SharedL2CacheHierarchy
from component.o3cpu import MyO3CPU
from component.cost_models import cpu_cost, cache_cost, memory_cost, network_cost

ap = argparse.ArgumentParser()
ap.add_argument("--num_cores", type=int, default=4)   # 1 <= cores <= 16
ap.add_argument("--capacity" , type=int, default=4)   # in GB
ap.add_argument("--channels" , type=int, default=2)   # 1 <= channels <= 4
ap.add_argument("--l1-size"  , type=int, default=32)  # in KB
ap.add_argument("--l1-assoc" , type=int, default=8) 
ap.add_argument("--l2-size"  , type=int, default=2)   # in MB
ap.add_argument("--l2-assoc" , type=int, default=16)
ap.add_argument("--width"    , type=int, default=10)  # 1  <= W <= 32
ap.add_argument("--rob_size" , type=int, default=128) # 16 <= R <= 512
ap.add_argument("--int_regs" , type=int, default=128) # 32 <= I <= 512
ap.add_argument("--fp_regs"  , type=int, default=128) # 32 <= F <= 512
ap.add_argument("--sq_lq"    , type=int, default=128) # 16 <= LQ, SQ <= 512
ap.add_argument("--bidir"    , type=bool,default=True) # For RING network!!
args = ap.parse_args()
nrouters = (2 * args.num_cores) + 2 + 2  # (L1i + L1d) + L2 + MEM
if args.bidir:
    print("=> RING Network: Bidirectional")
    nlinks = 2 * nrouters
else:
    print("=> RING Network: Unidirectional")
    nlinks = nrouters

# Setup the Ruby cache hierarchy with ring topology
cache_hierarchy = PrivateL1SharedL2CacheHierarchy(
    l1_size=f"{args.l1_size}KB", l1_assoc=args.l1_assoc,
    l2_size=f"{args.l2_size}MB", l2_assoc=args.l2_assoc
)

if args.channels == 1:
    memory = SingleChannelDDR4_2400(size=f"{args.capacity}GB")
else:
    memory = DualChannelDDR4_2400(size=f"{args.capacity}GB")

core = MyO3CPU(width=args.width,
               rob_size=args.rob_size, 
               num_int_regs=args.int_regs, 
               num_fp_regs=args.fp_regs, 
               sq_lq=args.sq_lq
               )

processor = SimpleSwitchableProcessor( 
    starting_core_type=CPUTypes.KVM, 
    switch_core_type=core, 
    isa=ISA.X86, 
    num_cores=args.num_cores,
)
for c in processor.get_cores():
    c.core.usePerf = False

kernel = KernelResource(local_path="binaries/vmlinux-4.4.186")
disk   = DiskImageResource(local_path="disks/parsec.img", root_partition="1")

# The X86Board allows for Full-System X86 simulations.
board = X86Board(
    clk_freq="3GHz",
    processor=processor,
    memory=memory,
    cache_hierarchy=cache_hierarchy,
)

rcs = f"""
echo "[rcS] Boot done → request CPU switch (KVM→TIMING)"
M5=$(command -v m5 || echo /sbin/m5)
$M5 exit

echo "[rcS] Now in TIMING, reset stats and run workload"
$M5 resetstats
taskset -c 0-3 ./resnet_mt --channels 16 --size 8 --blocks 4 --threads {args.num_cores}
$M5 dumpstats
$M5 exit
"""

board.set_kernel_disk_workload(
    kernel=kernel,
    disk_image=disk,
    readfile_contents=rcs,
    kernel_args=[
        "console=ttyS0",       # force serial console output
        "earlyprintk=ttyS0",   # early boot messages to serial console
        "root=/dev/hda1",      # specify root filesystem partition
    ],
)

def exit_event_handler():
    print("first exit event: Kernel booted, switching CPU")
    processor.switch()
    yield False

    print("second exit event: Done, now exit")
    yield True

simulator = Simulator(
    board=board,
    on_exit_event={
        ExitEvent.EXIT: exit_event_handler(),
    },
)
simulator.run()

cpu_cost = cpu_cost(args.width, args.rob_size, args.int_regs, args.fp_regs, args.num_cores, args.sq_lq)
cache_cost = cache_cost(args.l1_size, args.l2_size)
memory_cost = memory_cost(args.capacity, args.channels)
network_cost = network_cost(nrouters, nlinks)

total_cost = cpu_cost + cache_cost + memory_cost + network_cost

# Output the total cost
print(f"Total cost of configuration: {total_cost} units")